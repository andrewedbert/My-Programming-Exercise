#Soal no 2: Given a radius of the circle, calculate the area of the circle
import math
x=float(input('Masukkan Radius Lingkaran: '))

a=(math.pi)*(math.pow(x,2))

print('Luas Lingkaran: '+str(a))