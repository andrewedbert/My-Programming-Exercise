#Soal no 4: Given a string. Create a program to remove the character you want
a=input('Masukkan Kata: ')
rep=input('Kata yang dihilangkan: ')
print(a.replace(rep,''))